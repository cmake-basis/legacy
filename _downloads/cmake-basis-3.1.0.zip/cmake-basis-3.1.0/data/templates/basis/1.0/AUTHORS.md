Introduction
============

This document lists the authors of this software and further people who
significantly contributed to it.

See the [README](/README.md) for general information and acknowledgements
of contributions other kind.



Authors
=======

The original authors of this software are:

- <author>



Contributors
============

Listed below are the names of the ones who contributed notably to this software.
