.. title:: Release Notes

.. meta::
   :description: Summary of changes, new features, and bug fixes for each BASIS release.

=============
Release Notes
=============

.. include:: ../ChangeLog.txt
