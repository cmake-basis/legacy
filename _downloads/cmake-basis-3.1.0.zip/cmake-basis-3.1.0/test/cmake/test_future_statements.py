#! /usr/bin/env python


# Some comment line

"""

 A doc string which is
   allowed before the future statements...
   
  This Python script is used to test the basis_configure_script
  CMake function which adds Python code to modify the search
  path for modules to the top of the script. This code must be
  inserted below all future statements, however!
  
"""

from __future__ import print_function
from __future__ import division


from __future__ import generators
from __future__ import unicode_literals



from __future__ import with_statement



from basis import utilities



