#pragma once
#ifndef HelloTopLevel_moda_h_
#define HelloTopLevel_moda_h_


namespace hellotoplevel {

void moda();

}


#endif // HelloTopLevel_moda_h_
