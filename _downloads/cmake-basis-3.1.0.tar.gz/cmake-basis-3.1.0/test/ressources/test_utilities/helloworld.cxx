/**
 * @file  helloworld.cxx
 * @brief Some executable target used for testing.
 */

#include <iostream>


int main (int, char **)
{
    std::cout << "Hello World!" << std::endl;
    return 0;
}
