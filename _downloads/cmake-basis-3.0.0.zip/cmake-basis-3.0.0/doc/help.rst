.. title:: Help

.. meta::
    :description: Report any issues with BASIS or request new features on GitHub.

============
Getting Help
============

Please report any issues with BASIS, including bug reports, feature requests, or support questions, on GitHub_.

.. _GitHub: https://github.com/schuhschuh/cmake-basis/issues
