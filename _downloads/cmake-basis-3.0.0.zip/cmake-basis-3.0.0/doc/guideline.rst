.. raw:: latex

  \clearpage


.. _Guidelines:

==========
Guidelines
==========

The following sections define common guidelines for the formatting of documents
such as in particular program code as well as other recommended coding guidelines.
Each organization employing BASIS, however, may define their own guidelines,
possibly using the following guidelines as reference.

.. toctree::

    guideline/plain-text-format
