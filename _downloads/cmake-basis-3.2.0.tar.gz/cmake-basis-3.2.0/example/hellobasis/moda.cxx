#include <iostream>

#include <hellotoplevel/moda.h>

namespace hellotoplevel {


void moda()
{
  std::cout << "Called the moda() function." << std::endl;
}


} // namespace hellotoplevel
