.. meta::
    :description: This BASIS how-to guide describes how example and test data
                  can be stored outside the source tree of a software project.

==================
Managing Test Data
==================

.. note:: This how-to guide has to be written yet.

This document describes how example and test data can be stored outside the source tree.

.. seealso:: http://www.cmake.org/Wiki/ITK/Git/Develop/Data#ExternalData
.. seealso:: http://vtk.org/Wiki/ITK_Release_4/Testing_Data
