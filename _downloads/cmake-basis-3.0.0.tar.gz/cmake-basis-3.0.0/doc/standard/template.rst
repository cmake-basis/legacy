.. meta::
    :description: This article describes the software project template of BASIS,
                  a build system and software implementation standard.

================
Project Template
================

While you can create or use any custom template you like, it is highly recommended
that templates follow the BASIS :doc:`/standard`. In addition to the other standards,
for BASIS compliance templates must meet the requirements outlined below.

.. seealso:: The :doc:`/howto/use-and-customize-templates` How-to explains how to make use of templates.

**Benefits**

Anyone familar with the standard will be able to quickly
navigate the source tree and easily integrate your project into their own
because the setup is designed for consistency and interoperability. The 
idea is to make projects easier for developers to create, share, and use. 

BASIS Standardized Templates provide and automate the following steps:

- Configuration of the build, testing, installation, and packaging.
- Common directory structure which can be found at :doc:`fhs`.
- CMake_'s ``CMakeLists.txt`` file setup.
- Basic build flags that are required.


.. _TemplateLayout:

Template Layout
===============

::

  - template_name/
      - 1.0/
          + _config.py
          + src/
          + config/
          + data/
          + doc/
          + example/
          + modules/
          + test/
      - 1.1/
      - 2.0/
      - 2.1/
      - .../

.. note:: Only the files which were modified or added have to be present in the new template.
          The ``basisproject`` tool will look in older template directories for any missing files.


Template Versions
-----------------

The template system is designed to help automate updates of existing libraries to new template versions.
Whenever a template file is modified or removed, the previous project template has to be copied to a
new directory with an updated template version! Otherwise, the three-way diff merge used by the
``basisproject`` tool to update existing projects to this newer template will fail.



Standard Project Files
======================

Required Project Files
----------------------

The following files have to be part of any project which follows the :doc:`fhs`.
This is the minimal set of project files provided
when instantiating a new software project. Besides these files, a project
will have either a ``src/`` directory or a ``modules/`` directory,
or even both of them. See below for a description of these directories.

.. _README:

**README.txt**
    This is the main (root) documentation file. Every user is
    assumed to first read this file, which in turn will refer
    them to the more extensive documentation. This file in
    particular introduces the software package shortly, including a
    summary of the package files. Moreover, it refers to the
    :ref:`INSTALL.txt <INSTALL>` and :ref:`COPYING.txt <COPYING>`
    files for details on the build and installation and software license,
    respectively. Furthermore, references to scientific articles related
    to the software package shall be included in this file.

**AUTHORS.txt**
    Names the authors of the software package. People who
    notably contributed to the software directly should also be named
    here as well, even if they did not actually edit any project
    file. Others, who mostly contributed indirectly should be
    named in the :ref:`README.txt <README>` file instead. No author names shall
    be given in any particular source code file, as these are generally
    edited by multiple persons and updating the authors information
    within each source file is tedious.

.. _COPYING:

**COPYING.txt**
    Contains copyright and license information. If some files
    of the project were copied from other sources, the copyright
    and license information of these files shall be stated here
    as well. It is important to clearly state which copyright
    and license text corresponds to which project files.

.. _INSTALL:

**INSTALL.txt**
    Contains build and installation instructions. As the build
    of all projects which follow BASIS is very similar, this
    file shall only describe additional steps/CMake variables
    which are not described in the :doc:`/howto/install` guide.

.. _BasisProject:

:apidoc:`BasisProject.cmake`
    Sets basic information about a BASIS Project and calls the
    :apidoc:`basis_project()` command.
    The basic project information, also known as metadata,
    will typically include the project name and release version, 
    its brief description which is used for the packaging, 
    and the dependencies. Note that additional dependencies may be given 
    by the CMake code in the :ref:`config/Depends.cmake <Depends>` file, 
    if such file is present. If the project is a module of another project, 
    this file is read by the top-level project to be able to identify its 
    modules and the dependencies among them.

**CMakeLists.txt**
    The root CMake configuration file. **Do not edit this file.**


Common Project Files
--------------------

**build/CMakeLists.txt**
    CMake configuration file for bundle build (also referred to as super-build)
    of the project and all or some of its prerequisites. The source packages
    of the prerequisites are either downloaded during the bundle build or
    may be included with the distribution package. In the latter case, these
    source packages shall be placed in the build/ directory next to this
    CMake configuration file.

**CTestConfig.cmake**
    The CTest_ configuration file. This file in particular
    specifies the URL of the CDash_ dashboard of the project
    where test results should be submitted to.

.. _Settings:

**config/Settings.cmake**
    This is the main CMake script file used to configure the build
    system, and BASIS in particular. Any CMake code required to configure
    the build system, such as adding common compiler flags, or adding
    common definitions which have not yet been added by the generic code
    used by BASIS to utilize a found dependency should go into this file.

**config/ScriptConfig.cmake.in**
    See the documentation on the :doc:`build of script targets <scripttargets>`
    for details on how this :ref:`script configuration <ScriptConfig>` is used.

**data/CMakeLists.txt**
    This CMake configuration file contains code to simply install every file
    and directory from the source tree into the ``INSTALL_DATA_DIR`` directory
    of the installation tree.

**doc/CMakeLists.txt**
    This CMake configuration file adds rules to build the documentation
    from, for example, the in-source comments using Doxygen_ or reStructuredText_
    sources using Sphinx_. Moreover, for every documentation file, such as the
    software manual, the :apidoc:`basis_add_doc()` command has to be added to
    this file.

**doc/index.rst**
    The main page of the `comprehensive` software manual which may also serve as
    project web site at the same time.

**doc/manual/index.rst**
    The main page of the `condensed` software manual, i.e., a manual which focuses
    on the use of the software rather than it's installation and detailed reference.

**doc/guide/index.rst**
    The main page of the developer's guide which is intended for those who continue
    development or maintenance of the software.

**doc/site/indes.rst**
    The main page of the project web site.

**example/CMakeLists.txt**
    This CMake configuration file contains by default code to install every
    file and directory from the source tree into the ``INSTALL_EXAMPLE_DIR``
    directory of the installation tree. It may be modified to configure
    and/or build certain files of the example if applicable or required.

**src/CMakeLists.txt**
    The definition of all software build targets shall be added to this
    file, using the commands :apidoc:`basis_add_library()` to add a shared,
    static, or module library, which can also be a module written in a scripting
    language, and :apidoc:`basis_add_executable()` to add an executable target,
    which can be either a binary or a script file. If appropriate,
    the source code files may be further organized in subdirectories
    of the ``src/`` directory, in which case either separate
    ``CMakeLists.txt`` files can be used for each subdirectory,
    or yet all targets are added to the ``src/CMakeLists.txt``
    file using relative paths which include the subdirectory in which
    the source files are found. In general, if the number of source
    code files is low, i.e., close to or below 20, no subdirectory
    structure is required.

**test/CMakeLists.txt**
    Tests are added to this build configuration file using the
    :apidoc:`basis_add_test()` command. The test input files are usually put
    in a subdirectory named ``test/input/``, while the baseline
    data of the expected test output is stored inside a subdirectory
    named ``test/baseline/``. Generally, however, the :doc:`fhs` of
    BASIS does not dictate how the test sources, input, and baseline
    data have to be organized inside the ``test/`` directory.

**test/internal/CMakeLists.txt**
    More elaborate and extended tests which are intended for internal use only
    and which shall be excluded from the public source distribution package
    are configured using this CMake configuration file. Reasons for excluding
    tests from a public distribution are that some tests may depend on the
    internal software environment to succeed and further the particular
    machine architecture. Moreover, the size of the downloadable distribution
    packages shall be kept as small as possible and therefore some of the
    more specialized tests may be excluded from this distribution.

**modules/**
    If the project files are organized into conceptual cohesive groups,
    similar to the modularization goal of the ITK 4, this directory
    contains these conceptual modules of the project. The files of each
    module reside in a subdirectory named after the module. Note that each
    module itself is a project derived from this project template.


Advanced Project Files
----------------------

The customization of the following files is usually not required, and hence,
in most cases, most of these files need not to be part of a project.

**config/Components.cmake**
    Contains CMake code to configure the components used by
    component-based installers. Currently, component-based installers
    are not very well supported by BASIS, and hence this file
    is mostly unused and is yet subject to change.

.. _Config_in:

**config/Config.cmake.in**
    This is the template of the package configuration file.
    When the project is configured/installed using CMake,
    a configured version of this file is copied to the build
    or installation tree, respectively, where the information
    about the package configuration is substituted as appropriate
    for the actual build/installation of the package. For example,
    the configured file contains the absolute path to the
    installed public header files such that other packages can
    easily add this path to their include search path.
    The `find_package()`_ command of CMake, in particular, will look
    for this file and automatically import the CMake settings when
    this software package was found. For many projects, the default
    package configuration file of BASIS which is used if this file
    is missing in the project's ``config/`` directory,
    is sufficient and thus this file is often not required.

**config/ConfigSettings.cmake**
    This file sets CMake variables for use in the
    :ref:`config/Config.cmake.in <Config_in>` file. As the package configuration
    for the final installation differs from the one of the build tree,
    this file has to contain CMake code to set the variables used in the
    :ref:`config/Config.cmake.in  <Config_in>` file differently depending on whether
    the variables are being set for use within the build tree or the
    installation tree. This file only needs to be present if the project
    uses a custom :ref:`config/Config.cmake.in  <Config_in>` file, which in turn
    contains CMake variables whose value differs between build tree and
    installation.

**config/ConfigUse.cmake.in**
    This file is provided for convenience of the user of the
    software package. It contains CMake code which uses the
    variables set by the package configuration file (i.e.,
    the file generated from the file :ref:`config/Config.cmake.in <Config_in>`)
    in order to configure the build system of packages which
    use this software packages properly such that they can
    make use of this software. For example, the package
    configuration sets a variable to a list of include directories
    have to be added to the include search path. This file would then contain
    CMake instructions to actually add these directories to the path.

**config/ConfigVersion.cmake.in**
    This file accompanies the package configuration file
    generated from the :ref:`config/Config.cmake.in  <Config_in>` file. It is used
    by CMake's `find_package()`_ command to identify versions of this software
    package which are compatible with the version requested by the dependent
    project. This file needs almost never be customized by a project
    and thus should generally not be included in a project's source tree.

.. _Depends:

**config/Depends.cmake**
    If the generic code used by BASIS to resolve the dependencies on external
    packages is not sufficient, add this file to your project. CMake code required
    to find and make use of external software packages properly shall be added
    to this file. In order to only make use of the variables set by the package
    configuration of the found dependency, consider to add a dependency entry
    to the :ref:`BasisProject.cmake <BasisProject>` file instead and code to use
    these variables to :ref:`config/Settings.cmake <Settings>`.

**config/Package.cmake**
    Configures CPack_, the package generator of CMake.
    The packaging of software using CPack is currently not completely
    supported by BASIS. This template file is yet subject to change.

**CTestCustom.cmake.in**
    This file defines CTest_ variables which
    `customize CTest <http://www.vtk.org/Wiki/CMake_Testing_With_CTest#Customizing_CTest>`_.


Custom Substitutions
====================

The template configuration file named ``_config.py`` and located in the top directory of each project
template defines not only which files constitute a project, but also the available substitution parameters
and defaults used by ``basisproject``. The template configuration file requires a basic understanding
of Python syntax, but is fairly easy to understand even without much experience. To get an idea of the
syntax, take a look at the example below. A complete example can be found in the BASIS source
package in ``data/templates/basis/1.0/_config.py``.

.. code-block:: python

    # project template configuration script for basisproject tool

    # ------------------------------------------------------------------------------
    # required project files
    required = [
      'AUTHORS.txt',
      'README.txt',
      'INSTALL.txt',
      'COPYING.txt',
      'CMakeLists.txt',
      'BasisProject.cmake'
    ]

    # ------------------------------------------------------------------------------
    # optional project files
    options = {
      'config-settings' : {
        'desc' : 'Include/exclude custom Settings.cmake file.',
        'path' : [ 'config/Settings.cmake' ]
      },
      'config' : {
        'desc' : 'Include/exclude all custom configuration files.',
        'deps' : [
                   'config-settings'
                 ]
      },
      'data' : {
        'desc' : 'Add/remove directory for auxiliary data files.',
        'path' : [ 'data/CMakeLists.txt' ]
      }
    }

    # ------------------------------------------------------------------------------
    # preset template options
    presets = {
      'minimal' : {
        'desc' : 'Choose minimal project template.',
        'args' : [ 'src' ]
      },
      'default' : {
        'desc' : 'Choose default project template.',
        'args' : [ 'doc', 'doc-rst', 'example', 'include', 'src', 'test' ]
      },
      'toplevel' : {
        'desc' : 'Create toplevel project.',
        'args' : [ 'doc', 'doc-rst', 'example', 'modules' ]
      },
      'module' : {
        'desc' : 'Create module of toplevel project.',
        'args' : [ 'include',   'src',   'test' ]
      }
    }

    # ------------------------------------------------------------------------------
    # additional substitutions besides <project>, <template>,...
    from datetime import datetime as date

    substitutions = {
      # fixed computed substitutions
      'date'  : date.today().strftime('%x'),
      'day'   : date.today().day,
      'month' : date.today().month,
      'year'  : date.today().year,
      # substitutions which can be overridden using a command option
      'vendor' : {
        'help'    : "Package vendor ID (e.g., acronym of provider and/or division).",
        'default' : "SBIA"
      },
      'copyright' : {
        'help'    : "Copyrigth statement optionally including years, but not \". All rights reserved.\".",
        'default' : str(date.today().year) + " University of Pennsylvania"
      },
      'license' : {
        'help'    : "Software license statement, e.g., \"Simplified BSD\" or reference to license text.",
        'default' : "See http://www.rad.upenn.edu/sbia/software/license.html or COPYING file."
      },
      'contact' : {
        'help'    : "Package contact information.",
        'default' : "<vendor> <<vendor>-software at uphs.upenn.edu>"
      }
    }

.. note:: The substitutions are applied recursively up to a depth of 3. Hence, if the value of
          a substitution is another substitution tag, it will be replaced by the value of
          that respective substitution. See the ``contact`` substitution above for an example.

Binary Template Files
---------------------

In general, template files are assumed to be binary and thus no substitution is performed,
unless the template file is known to be a text file. Whether or not a template file is considered
to be a text file for which subsitution takes place depends on its `MIME type <https://en.wikipedia.org/wiki/MIME>`_ . 
The ``basisproject`` tool uses the `Python MIME types module <http://docs.python.org/2/library/mimetypes.html>`_
in order to determine the type of each template file. In addition to the default types known
by this module, the file name extensions .cmake, .md, .mdown, .markdown, .rst, .dox, and .in
are treated as text files.

.. _CMake: http://www.cmake.org/
.. _CDash: http://www.cdash.org/
.. _CTest: http://www.cmake.org/cmake/help/v2.8.8/ctest.html
.. _CPack: http://www.cmake.org/cmake/help/v2.8.8/cpack.html
.. _Doxygen: http://www.stack.nl/~dimitri/doxygen/
.. _Sphinx: http://sphinx.pocoo.org/
.. _reStructuredText: http://docutils.sourceforge.net/rst.html
.. _find_package(): http://www.cmake.org/cmake/help/v2.8.8/cmake.html#command:find_package
