// C++ comment
  // C++ comment

/* C comment */

/* Multiline
   C
   Comment


*/

#include <iostream>

char str[] = "multi\
line\
string\
literal";

using namespace std;


int main(
  int argc /*count*/,
  char* argv[] /*array*/)
{
  /* comment start */ int x = 0;
  char* s = 
  /* comment start */"foo";
  int y = 2
  /* tricky stuff *//
  2;
  cerr << "Hello, \"world!" << '\'' << endl;
}
